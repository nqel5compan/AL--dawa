import { NextResponse, type NextRequest } from "next/server";

/**
 * CSP frame-ancestors وقت التشغيل — يضبط من .env (ALLOWED_FRAME_ANCESTORS).
 * الافتراضي 'self'.
 *
 * + فحص Origin/Host على الطلبات المُعدِّلة (POST/PUT/PATCH/DELETE) — حماية CSRF:
 *   لو Origin موجود ومختلف عن PUBLIC_BASE_URL → 403.
 *   بلا PUBLIC_BASE_URL يُقارن host الـ Origin مع host الطلب.
 *   الطلبات بلا Origin (عملاء غير متصفحين / GET) تمر.
 */
const MUTATING = new Set(["POST", "PUT", "PATCH", "DELETE"]);

function originAllowed(req: NextRequest): boolean {
  const origin = req.headers.get("origin");
  if (!origin) return true;
  let originHost = "";
  try {
    originHost = new URL(origin).host.toLowerCase();
  } catch {
    return false; // Origin تالف
  }
  const base = (process.env.PUBLIC_BASE_URL || "").trim().replace(/\/+$/, "").toLowerCase();
  if (base) {
    let baseHost = "";
    try {
      baseHost = new URL(base).host.toLowerCase();
    } catch {
      baseHost = base; // قيمة بلا scheme — قارنها كما هي
    }
    return originHost === baseHost || origin.toLowerCase().replace(/\/+$/, "") === base;
  }
  const host = (req.headers.get("host") || "").toLowerCase();
  return host ? originHost === host : true;
}

export default function middleware(req: NextRequest) {
  if (MUTATING.has(req.method) && !originAllowed(req)) {
    return NextResponse.json({ error: "ORIGIN_FORBIDDEN" }, { status: 403 });
  }
  const res = NextResponse.next();
  const frameAncestors = (process.env.ALLOWED_FRAME_ANCESTORS || "").trim() || "'self'";
  res.headers.set("Content-Security-Policy", `frame-ancestors ${frameAncestors}`);
  return res;
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
